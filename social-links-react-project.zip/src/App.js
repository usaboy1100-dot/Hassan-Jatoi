import React from 'react';

// Data for the social links
const socialLinks = [
  { name: 'Facebook', url: 'https://facebook.com', smallText: 'facebook.com', icon: 'facebook' },
  { name: 'Instagram', url: 'https://instagram.com', smallText: 'instagram.com', icon: 'instagram' },
  { name: 'WhatsApp', url: 'https://wa.me/966XXXXXXXXX', smallText: 'Chat', icon: 'whatsapp' },
  { name: 'YouTube', url: 'https://youtube.com', smallText: 'youtube.com', icon: 'youtube' },
  { name: 'TikTok', url: 'https://www.tiktok.com', smallText: 'tiktok.com', icon: 'tiktok' },
  { name: 'X', url: 'https://x.com', smallText: 'x.com', icon: 'x' },
  { name: 'LinkedIn', url: 'https://linkedin.com', smallText: 'linkedin.com', icon: 'linkedin' },
  { name: 'Snapchat', url: 'https://snapchat.com', smallText: 'snapchat.com', icon: 'snapchat' },
  { name: 'Pinterest', url: 'https://pinterest.com', smallText: 'pinterest.com', icon: 'pinterest' },
  { name: 'Reddit', url: 'https://reddit.com', smallText: 'reddit.com', icon: 'reddit' },
  { name: 'GitHub', url: 'https://github.com', smallText: 'github.com', icon: 'github' },
  { name: 'Discord', url: 'https://discord.com', smallText: 'discord.com', icon: 'discord' },
  { name: 'Telegram', url: 'https://telegram.org', smallText: 'telegram.org', icon: 'telegram' },
];
// Base URL for Simple Icons CDN
const ICON_BASE_URL = "https://cdn.jsdelivr.net/npm/simple-icons@v9/icons/";

const App = () => {
  const cardClasses =
    "w-full max-w-4xl bg-white/5 backdrop-blur-md rounded-xl p-5 md:p-7 shadow-[0_6px_30px_rgba(2,6,23,0.6)] border border-white/5";

  const iconClasses =
    "flex items-center gap-3 p-3 rounded-xl bg-white/[0.04] text-slate-300 transition-all duration-200 ease-out hover:-translate-y-[6px] hover:bg-white/10 hover:shadow-2xl hover:shadow-cyan-900/50 border border-transparent hover:border-cyan-500/20";

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-b from-[#071023] to-[#081226] font-sans">
      <div className={cardClasses} role="region" aria-label="Social media links">
        <div className="flex items-center gap-3 mb-4">
          <svg className="w-9 h-9 flex-shrink-0" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <rect width="24" height="24" rx="6" fill="#0ea5a4"></rect>
            <path d="M7 12h10M7 7h10M7 17h10" stroke="#042027" strokeWidth="1.4" strokeLinecap="round"></path>
          </svg>
          <div>
            <h1 className="text-xl font-semibold text-white tracking-tight">
              Social Media — Quick Links
            </h1>
            <p className="text-sm text-slate-400 mt-0.5">
              Click any logo to open the official social profile or homepage in a new tab.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {socialLinks.map((link) => (
            <a
              key={link.name}
              className={iconClasses}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={link.name}
            >
              <img
                src={`${ICON_BASE_URL}${link.icon}.svg`}
                alt={`${link.name} logo`}
                className="w-8 h-8 flex-shrink-0"
                onError={(e) => (e.currentTarget.style.display = 'none')}
              />
              <div className='truncate'>
                <div className="text-sm font-medium text-slate-100 truncate">{link.name}</div>
                <div className="text-xs text-slate-400 truncate">{link.smallText}</div>
              </div>
            </a>
          ))}
        </div>
        <div className="mt-4 pt-4 border-t border-white/5 text-center text-xs text-slate-400">
          <p className="mb-0.5">Software Developed By Hassan jatoi</p>
          <p className="mt-0">
            WhatsApp:
            <a 
              href="tel:+923083500829"
              className="text-cyan-300 hover:text-cyan-200 transition-colors ml-1"
            >
              03083500829
            </a>
          </p>
        </div>
      </div>
      <a
        className="fixed right-6 bottom-6 w-14 h-14 rounded-full flex items-center justify-center bg-gradient-to-br from-[#25D366] to-[#128C7E] shadow-xl transition-transform duration-300 hover:scale-110 z-50 border-4 border-white/10"
        href="https://wa.me/966XXXXXXXXX"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Open WhatsApp chat"
      >
        <img
          src={`${ICON_BASE_URL}whatsapp.svg`}
          alt="WhatsApp"
          className="w-7 h-7"
          style={{ filter: 'none' }}
        />
      </a>
    </div>
  );
};

export default App;
